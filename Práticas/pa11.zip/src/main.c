#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAXPALAVRA 10000

typedef struct No {
    char palavra[MAXPALAVRA];
    int *paginas;
    int num_paginas;
    int altura;
    struct No *esq;
    struct No *dir;
} No;

typedef No *indrem_t;

// Protótipos das funções AVL
int altura(No *N);
int max(int a, int b);
No *novoNo(char *palavra, int pagina);
No *rotacaoDireita(No *y);
No *rotacaoEsquerda(No *x);
int getBalance(No *N);
No *inserir(No* no, char *palavra, int pagina);
void emOrdem(const No *raiz);

// Função para obter a altura do nó
int altura(No *N) {
    if (N == NULL)
        return 0;
    return N->altura;
}

// Função utilitária para obter o maior de dois inteiros
int max(int a, int b) {
    return (a > b)? a : b;
}

// Função utilitária para criar um novo nó da árvore AVL
No *novoNo(char *palavra, int pagina) {
    No *no = (No*)malloc(sizeof(No));
    strcpy(no->palavra, palavra);
    no->paginas = (int*)malloc(sizeof(int));
    no->paginas[0] = pagina;
    no->num_paginas = 1;
    no->altura = 1; // Novo nó é inicialmente adicionado na folha
    no->esq = NULL;
    no->dir = NULL;
    return(no);
}

// Função utilitária para fazer rotação à direita do nó y
No *rotacaoDireita(No *y) {
    No *x = y->esq;
    No *T2 = x->dir;

    // Realiza rotação
    x->dir = y;
    y->esq = T2;

    // Atualiza alturas
    y->altura = max(altura(y->esq), altura(y->dir)) + 1;
    x->altura = max(altura(x->esq), altura(x->dir)) + 1;

    // Retorna nova raiz
    return x;
}

// Função utilitária para fazer rotação à esquerda do nó x
No *rotacaoEsquerda(No *x) {
    No *y = x->dir;
    No *T2 = y->esq;

    // Realiza rotação
    y->esq = x;
    x->dir = T2;

    // Atualiza alturas
    x->altura = max(altura(x->esq), altura(x->dir)) + 1;
    y->altura = max(altura(y->esq), altura(y->dir)) + 1;

    // Retorna nova raiz
    return y;
}

// Obter o fator de balanceamento do nó N
int getBalance(No *N) {
    if (N == NULL)
        return 0;
    return altura(N->esq) - altura(N->dir);
}

// Utility function to check if the page already exists
bool pageExists(int *pages, int num_paginas, int pagina) {
    for (int i = 0; i < num_paginas; ++i) {
        if (pages[i] == pagina) {
            return true;
        }
    }
    return false;
}

// Utility function to insert a page into the sorted array of pages
void insertPageSorted(int **pages, int *num_paginas, int pagina) {
    int i;
    for (i = *num_paginas - 1; (i >= 0 && (*pages)[i] > pagina); i--) {
        (*pages)[i + 1] = (*pages)[i];
    }
    (*pages)[i + 1] = pagina;
    (*num_paginas)++;
}

// Função recursiva para inserir uma palavra na árvore AVL e retornar a nova raiz da árvore
No *inserir(No* no, char *palavra, int pagina) {
    // 1. Realiza a inserção normal de uma árvore de busca binária
    if (no == NULL)
        return(novoNo(palavra, pagina));

    // If the word already exists in the tree, add the page
    if (strcmp(palavra, no->palavra) == 0) {
        if (!pageExists(no->paginas, no->num_paginas, pagina)) {
            // Reallocate memory to add a new page if it does not already exist
            int *novaListaPaginas = realloc(no->paginas, (no->num_paginas + 1) * sizeof(int));
            if (novaListaPaginas != NULL) {
                no->paginas = novaListaPaginas;
                insertPageSorted(&(no->paginas), &(no->num_paginas), pagina);
            } else {
                // Handle memory reallocation error here
                fprintf(stderr, "Error reallocating memory.\n");
                exit(EXIT_FAILURE);
            }
        }
        return no;
    }

    if (strcmp(palavra, no->palavra) < 0)
        no->esq = inserir(no->esq, palavra, pagina);
    else if (strcmp(palavra, no->palavra) > 0)
        no->dir = inserir(no->dir, palavra, pagina);

    // 2. Atualiza a altura do nó ancestral
    no->altura = 1 + max(altura(no->esq), altura(no->dir));

    // 3. Obtém o fator de balanceamento para verificar se o nó ancestral se desequilibrou
    int balance = getBalance(no);

    // Se o nó se desequilibrou, então existem 4 casos

    // Caso Esquerda-Esquerda
    if (balance > 1 && strcmp(palavra, no->esq->palavra) < 0)
        return rotacaoDireita(no);

    // Caso Direita-Direita
    if (balance < -1 && strcmp(palavra, no->dir->palavra) > 0)
        return rotacaoEsquerda(no);

    // Caso Esquerda-Direita
    if (balance > 1 && strcmp(palavra, no->esq->palavra) > 0) {
        no->esq = rotacaoEsquerda(no->esq);
        return rotacaoDireita(no);
    }

    // Caso Direita-Esquerda
    if (balance < -1 && strcmp(palavra, no->dir->palavra) < 0) {
        no->dir = rotacaoDireita(no->dir);
        return rotacaoEsquerda(no);
    }

    // Retorna o ponteiro do nó (inalterado)
    return no;
}

// Função para fazer percurso em ordem na árvore e imprimir as palavras e páginas
void emOrdem(const No *raiz) {
    if (raiz != NULL) {
        emOrdem(raiz->esq);
        // Código anterior de imprimeNo agora aqui
        printf("%s: ", raiz->palavra);
        for (int i = 0; i < raiz->num_paginas; i++) {
            printf("%d ", raiz->paginas[i]);
        }
        printf("\n");
        // Continua a travessia
        emOrdem(raiz->dir);
    }
}


int main() {
    char palavra[MAXPALAVRA];
    int pagina;
    indrem_t meuind = NULL; 

    while (scanf("%s %d", palavra, &pagina) != EOF) {
        meuind = inserir(meuind, palavra, pagina);  
    }

    emOrdem(meuind); 
    return 0;
}