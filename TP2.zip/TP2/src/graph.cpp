//---------------------------------------------------------------------
// Arquivo      : graph.cpp
// Conteudo     : Implementação do grafo
// Autor        : Raissa Gonçalves Diniz (raissagdiniz@gmail.com)
// Historico    : 28/10/2023 - arquivo criado
//---------------------------------------------------------------------

#include "../include/graph.hpp"

Graph::Graph() : V(0), adjList(nullptr) {
    colors = new int[V]; // inicializa com o número de vértices
    for (int i = 0; i < V; i++)
        colors[i] = -1; // valor padrão para cor
}

Graph::~Graph() {
     for (int i = 0; i < V; ++i) {
        delete adjList[i]; // Delete each LinkedList instance
    }
    delete[] adjList; // Then delete the array of pointers
    delete[] colors;
}

void Graph::insertVertex() {
    // Realocate the adjList array with one additional slot
    LinkedList** newAdjList = new LinkedList*[V + 1];

    // Copy existing adjacency list pointers to the new array
    for (int i = 0; i < V; ++i) {
        newAdjList[i] = adjList[i];
    }

    // Initialize the new vertex's adjacency list
    newAdjList[V] = new LinkedList;

    // Delete the old adjList pointer array after copying
    delete[] adjList;

    // Update the adjList pointer to the new array
    adjList = newAdjList;

    // Increment the vertex count
    ++V;
}

void Graph::insertEdge(int v, int w) {
    if (v < V && w < V) { // verifica se os vértices existem
        adjList[v]->insert(w); // adiciona w à lista de v, mas não v à lista de w
    }
}

int Graph::numVertices() {
    return V;
}

int Graph::numEdges() {
    int totalArestas = 0;
    for (int i = 0; i < V; ++i) {
        totalArestas += adjList[i]->size(); // Presume-se que 'size' forneça o número de elementos na lista ligada
    }
    return totalArestas / 2; // Cada aresta é contada duas vezes, então dividimos por 2.
}

void Graph::addColor(int v, int c) {
    if (v >= 0 && v < V) {
        colors[v] = c;
    }
}

int Graph::getVertexColor(int v) {
    if (v >= 0 && v < V) {
        return colors[v];
    }
    return -1; // cor inválida
}

bool Graph::isGreedy(int v, int c) {
    // Se a cor for 1, é sempre guloso.
    if (c == 1) {
        return true;
    }

    // Verifica se o grafo é completo
    if (numEdges() == (V * (V - 1)) / 2) {
        return true;
    }

    // Aloca dinamicamente o array lesserColors
    bool* lesserColors = new bool[c];
    for (int i = 0; i < c; i++) {
        lesserColors[i] = false;
    }

    Node* current = adjList[v]->getHead(); // Pega o nó cabeça da lista de adjacência para o vértice v

    // Verifica as cores dos vértices adjacentes
    while (current != nullptr) {
        int adjacent = current->data; // O vértice adjacente

        // Se um vértice adjacente tem a mesma cor, não é guloso.
        if (c == colors[adjacent]) {
            delete[] lesserColors; // Libera a memória alocada
            return false;
        }

        // Se a cor do vértice adjacente for menor que c, marque-a como true.
        if (colors[adjacent] < c) {
            lesserColors[colors[adjacent]] = true;
        }

        current = current->next; // Avança para o próximo vértice adjacente
    }

    // Verifica se todas as cores menores que c estão presentes entre os vizinhos
    for (int i = 1; i < c; ++i) {
        if (!lesserColors[i]) {
            delete[] lesserColors; // Libera a memória alocada
            return false; // Se uma cor menor não estiver presente entre os vizinhos, não é uma coloração gulosa
        }
    }

    delete[] lesserColors; // Libera a memória alocada antes de retornar
    // Se todas as condições forem satisfeitas, é uma coloração gulosa.
    return true;
}